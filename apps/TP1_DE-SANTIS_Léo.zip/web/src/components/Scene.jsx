import GameOfLife from './GameOfLife.jsx'

export default function Scene(props){ 
    return <GameOfLife {...props} /> 
}
